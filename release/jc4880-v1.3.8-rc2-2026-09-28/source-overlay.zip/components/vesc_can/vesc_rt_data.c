/*
    Copyright 2025 Super VESC Display
    Copyright 2026 Adapted to ESP-IDF for ESP32-P4 (GPL-3.0).
*/

#include "vesc_can/vesc_rt_data.h"

#include "vesc_can/buffer.h"
#include "vesc_can/comm_can.h"
#include "vesc_can/vesc_lisp_poll.h"
#include "vesc_can/vesc_io_data.h"
#include "vesc_can/vesc_lisp_panel.h"
#include "vesc_can/vesc_ride_mode.h"
#include "sdkconfig.h"

#include "esp_err.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include <string.h>

static const char *TAG = "vesc_rt";

/* SETUP_VALUES selective request mask bits. */
#define MASK_TEMP_MOS           (1U << 0)
#define MASK_TEMP_MOTOR         (1U << 1)
#define MASK_CURRENT_MOTOR      (1U << 2)
#define MASK_CURRENT_IN         (1U << 3)
#define MASK_DUTY_NOW           (1U << 4)
#define MASK_RPM                (1U << 5)
#define MASK_SPEED              (1U << 6)
#define MASK_V_IN               (1U << 7)
#define MASK_BATTERY_LEVEL      (1U << 8)
#define MASK_AMP_HOURS          (1U << 9)
#define MASK_AMP_HOURS_CHARGED  (1U << 10)
#define MASK_WATT_HOURS         (1U << 11)
#define MASK_WATT_HOURS_CHARGED (1U << 12)
#define MASK_TACHOMETER         (1U << 13)
#define MASK_TACHOMETER_ABS     (1U << 14)
#define MASK_POSITION           (1U << 15)
#define MASK_FAULT_CODE         (1U << 16)
#define MASK_VESC_ID            (1U << 17)
#define MASK_NUM_VESCS          (1U << 18)
#define MASK_BATTERY_WH         (1U << 19)
#define MASK_ODOMETER           (1U << 20)
#define MASK_UPTIME_MS          (1U << 21)

static vesc_setup_values_t s_rt_data;
static bool                s_data_received      = false;
static uint32_t            s_temp_received_mask = 0;
static uint32_t            s_temp_mos_rx_time   = 0;
static uint32_t            s_temp_motor_rx_time = 0;
static bool                s_active             = false;
static uint8_t             s_target_vesc_id     = 10;
static uint32_t            s_request_interval_ms = 100;
static uint32_t            s_last_request_ms    = 0;
static TaskHandle_t        s_task_handle        = NULL;

static inline uint32_t millis_now(void)
{
    return (uint32_t)(esp_timer_get_time() / 1000);
}

void vesc_rt_data_init(uint8_t target_vesc_id, uint32_t poll_interval_ms)
{
    memset(&s_rt_data, 0, sizeof(s_rt_data));
    s_data_received       = false;
    s_temp_received_mask  = 0;
    s_temp_mos_rx_time    = 0;
    s_temp_motor_rx_time  = 0;
    s_active              = false;
    s_target_vesc_id      = target_vesc_id;
    s_request_interval_ms = poll_interval_ms ? poll_interval_ms : 100;
    s_last_request_ms     = 0;
    ESP_LOGI(TAG, "init target=%u interval=%u ms", target_vesc_id,
             (unsigned)s_request_interval_ms);
}

bool vesc_rt_data_is_active(void) { return s_active; }

void vesc_rt_data_start(void)
{
    s_active           = true;
    s_last_request_ms  = 0;
    ESP_LOGI(TAG, "polling started");
}

void vesc_rt_data_stop(void)
{
    s_active = false;
    ESP_LOGI(TAG, "polling stopped");
}

void vesc_rt_data_request(void)
{
    uint32_t mask =
        MASK_AMP_HOURS |
        MASK_TEMP_MOS |
        MASK_TEMP_MOTOR |
        MASK_CURRENT_MOTOR |
        MASK_CURRENT_IN |
        MASK_DUTY_NOW |
        MASK_RPM |
        MASK_BATTERY_LEVEL |
        MASK_SPEED |
        MASK_V_IN |
        MASK_WATT_HOURS |
        MASK_WATT_HOURS_CHARGED |
        MASK_TACHOMETER_ABS |
        MASK_FAULT_CODE |
        MASK_VESC_ID |
        MASK_BATTERY_WH |
        MASK_ODOMETER |
        MASK_UPTIME_MS;

    uint8_t  send_buffer[10];
    int32_t  ind = 0;
    send_buffer[ind++] = COMM_GET_VALUES_SETUP_SELECTIVE;
    buffer_append_uint32(send_buffer, mask, &ind);

    /* send=0: VESC will reply over CAN (PROCESS_*_BUFFER). Synced so this
     * reply can't interleave with the LISP-stats / IO-decode polls' replies
     * in the shared per-id reassembly buffer. */
    comm_can_send_buffer_sync(s_target_vesc_id, send_buffer, ind, 0, 60);
}

/* Wire widths for the known SETUP fields in official VESC 6.05 commands.c. */
static const uint8_t s_setup_field_bytes[] = {
    2, 2, 4, 4, 2, 4, 4, 2, 2, 4, 4,
    4, 4, 4, 4, 4, 1, 1, 1, 4, 4, 4
};

static bool setup_response_layout(const uint8_t *data, unsigned int len,
                                  uint32_t *mask, int32_t *field_start)
{
    if (!data || len < 1) return false;
    const uint8_t cmd = data[0];
    if (cmd != COMM_GET_VALUES_SETUP && cmd != COMM_GET_VALUES_SETUP_SELECTIVE) {
        return false;
    }
    *field_start = 1;
    *mask = 0xFFFFFFFFu;
    if (cmd == COMM_GET_VALUES_SETUP_SELECTIVE) {
        if (len < 5) return false;
        *mask = buffer_get_uint32(data, field_start);
    }
    /* Command47 sends all22 fields: 70 bytes including command. No prefix
     * may commit data. Selective future fields may follow the known prefix;
     * empty/unknown-only masks update nothing. */
    if (!(*mask & ((1u << 22) - 1u))) return false;
    unsigned int required = (unsigned int)*field_start;
    for (unsigned int bit = 0; bit < sizeof(s_setup_field_bytes); ++bit) {
        if (*mask & (1u << bit)) required += s_setup_field_bytes[bit];
    }
    if (len < required) {
        ESP_LOGW(TAG, "truncated setup response (%u < %u)", len, required);
        return false;
    }
    return true;
}

void vesc_rt_data_process_response(const uint8_t *data, unsigned int len)
{
    int32_t ind;
    uint32_t mask;
    if (!setup_response_layout(data, len, &mask, &ind)) return;

    if ((mask & MASK_TEMP_MOS) && ind + 2 <= (int)len)
        s_rt_data.temp_mos = buffer_get_float16(data, 1e1f, &ind);
    if ((mask & MASK_TEMP_MOTOR) && ind + 2 <= (int)len)
        s_rt_data.temp_motor = buffer_get_float16(data, 1e1f, &ind);
    if ((mask & MASK_CURRENT_MOTOR) && ind + 4 <= (int)len)
        s_rt_data.current_motor = buffer_get_float32(data, 1e2f, &ind);
    if ((mask & MASK_CURRENT_IN) && ind + 4 <= (int)len)
        s_rt_data.current_in = buffer_get_float32(data, 1e2f, &ind);
    if ((mask & MASK_DUTY_NOW) && ind + 2 <= (int)len)
        s_rt_data.duty_now = buffer_get_float16(data, 1e3f, &ind);
    if ((mask & MASK_RPM) && ind + 4 <= (int)len)
        s_rt_data.rpm = buffer_get_float32(data, 1e0f, &ind);
    if ((mask & MASK_SPEED) && ind + 4 <= (int)len)
        s_rt_data.speed = buffer_get_float32(data, 1e3f, &ind);
    if ((mask & MASK_V_IN) && ind + 2 <= (int)len)
        s_rt_data.v_in = buffer_get_float16(data, 1e1f, &ind);
    if ((mask & MASK_BATTERY_LEVEL) && ind + 2 <= (int)len)
        s_rt_data.battery_level = buffer_get_float16(data, 1e3f, &ind);
    if ((mask & MASK_AMP_HOURS) && ind + 4 <= (int)len)
        s_rt_data.amp_hours = buffer_get_float32(data, 1e4f, &ind);
    if ((mask & MASK_AMP_HOURS_CHARGED) && ind + 4 <= (int)len)
        s_rt_data.amp_hours_charged = buffer_get_float32(data, 1e4f, &ind);
    if ((mask & MASK_WATT_HOURS) && ind + 4 <= (int)len)
        s_rt_data.watt_hours = buffer_get_float32(data, 1e4f, &ind);
    if ((mask & MASK_WATT_HOURS_CHARGED) && ind + 4 <= (int)len)
        s_rt_data.watt_hours_charged = buffer_get_float32(data, 1e4f, &ind);
    if ((mask & MASK_TACHOMETER) && ind + 4 <= (int)len)
        s_rt_data.tachometer = buffer_get_float32(data, 1e3f, &ind);
    if ((mask & MASK_TACHOMETER_ABS) && ind + 4 <= (int)len)
        s_rt_data.tachometer_abs = buffer_get_float32(data, 1e3f, &ind);
    if ((mask & MASK_POSITION) && ind + 4 <= (int)len)
        s_rt_data.position = buffer_get_float32(data, 1e6f, &ind);
    if ((mask & MASK_FAULT_CODE) && ind + 1 <= (int)len)
        s_rt_data.fault_code = data[ind++];
    if ((mask & MASK_VESC_ID) && ind + 1 <= (int)len)
        s_rt_data.vesc_id = data[ind++];
    if ((mask & MASK_NUM_VESCS) && ind + 1 <= (int)len)
        s_rt_data.num_vescs = data[ind++];
    if ((mask & MASK_BATTERY_WH) && ind + 4 <= (int)len)
        s_rt_data.battery_wh = buffer_get_float32(data, 1e3f, &ind);
    if ((mask & MASK_ODOMETER) && ind + 4 <= (int)len)
        s_rt_data.odometer = buffer_get_uint32(data, &ind);
    if ((mask & MASK_UPTIME_MS) && ind + 4 <= (int)len)
        s_rt_data.uptime_ms = buffer_get_uint32(data, &ind);

    s_rt_data.rx_time = millis_now();
    s_data_received   = true;
    /* An unrelated selective response is fresh traffic, not a fresh
     * thermal sample. Keep the two sensors' ages independent. */
    if (mask & MASK_TEMP_MOS) s_temp_mos_rx_time = s_rt_data.rx_time;
    if (mask & MASK_TEMP_MOTOR) s_temp_motor_rx_time = s_rt_data.rx_time;
    s_temp_received_mask |= mask & (MASK_TEMP_MOS | MASK_TEMP_MOTOR);

    static uint32_t log_counter = 0;
    if (++log_counter >= 20) {
        log_counter = 0;
        float speed_kmh   = s_rt_data.speed * 3.6f;
        float odometer_km = s_rt_data.odometer / 1000.0f;
        float power_w     = s_rt_data.current_in * s_rt_data.v_in;
        /* Live telemetry once every 20 polls (~2 s) — useful when
         * debugging the VESC link, just noisy in the default log. */
        ESP_LOGD(TAG, "v=%.1fV i=%.1fA P=%.0fW spd=%.1fkm/h odo=%.1fkm",
                 s_rt_data.v_in, s_rt_data.current_in, power_w,
                 speed_kmh, odometer_km);
    }
}

void vesc_rt_data_process_can_response(const uint8_t *data, unsigned int len,
                                       int sender_id)
{
    if (sender_id < 0 || sender_id >= 255) return;
    /* utils_sys.c:utils_second_motor_id in official6.05 wraps254 to0. */
    const uint8_t second_motor_id = (uint8_t)((sender_id + 1) % 255);
    if (sender_id != (int)s_target_vesc_id && second_motor_id != s_target_vesc_id) return;
    int32_t ind;
    uint32_t mask;
    if (!setup_response_layout(data, len, &mask, &ind) || !(mask & MASK_VESC_ID)) return;
    /* Official 6.05 comm_can.c sends the base controller ID in the CAN
     * envelope even for internal motor2. SETUP bit17 (commands.c) carries
     * the selected logical motor ID. Require it for every CAN RT snapshot,
     * including replies whose envelope matches the target: another client
     * may have queried motor2 on that same controller. This is identity
     * selection, not authentication of CAN traffic. */
    for (unsigned int bit = 0; bit < 17; ++bit) {
        if (mask & (1u << bit)) ind += s_setup_field_bytes[bit];
    }
    if (data[ind] != s_target_vesc_id) return;
    vesc_rt_data_process_response(data, len);
}

void vesc_rt_data_inject(const vesc_setup_values_t *src)
{
    if (!src) return;
    s_rt_data = *src;
    s_rt_data.rx_time = millis_now();
    s_data_received   = true;
    s_temp_mos_rx_time = s_rt_data.rx_time;
    s_temp_motor_rx_time = s_rt_data.rx_time;
    s_temp_received_mask = MASK_TEMP_MOS | MASK_TEMP_MOTOR;
}

const vesc_setup_values_t *vesc_rt_data_get_latest(void) { return &s_rt_data; }

bool vesc_rt_data_is_fresh(void)
{
    if (!s_data_received) return false;
    uint32_t age = millis_now() - s_rt_data.rx_time;
    return age < 5000;
}

bool vesc_rt_data_temp_mos_is_fresh(void)
{
    return (s_temp_received_mask & MASK_TEMP_MOS) &&
           (uint32_t)(millis_now() - s_temp_mos_rx_time) < 5000;
}

bool vesc_rt_data_temp_motor_is_fresh(void)
{
    return (s_temp_received_mask & MASK_TEMP_MOTOR) &&
           (uint32_t)(millis_now() - s_temp_motor_rx_time) < 5000;
}

float vesc_rt_data_get_speed_kmh(void)
{
    return s_rt_data.speed * 3.6f;
}

float vesc_rt_data_get_trip_km(void)
{
    return s_rt_data.tachometer_abs / 1000.0f;
}

float vesc_rt_data_get_odometer_km(void)
{
    return s_rt_data.odometer / 1000.0f;
}

float vesc_rt_data_get_efficiency_whkm(void)
{
    float wh_consumed = s_rt_data.watt_hours - s_rt_data.watt_hours_charged;
    float distance_km = s_rt_data.tachometer_abs / 1000.0f;
    if (distance_km < 0.01f) return 0.0f;
    return wh_consumed / distance_km;
}

float vesc_rt_data_get_amp_hours(void)    { return s_rt_data.amp_hours; }
uint32_t vesc_rt_data_get_uptime_ms(void) { return s_rt_data.uptime_ms; }

void vesc_rt_data_loop(void)
{
    if (!s_active) return;
    uint32_t now = millis_now();
    if (now - s_last_request_ms >= s_request_interval_ms) {
        vesc_rt_data_request();
        s_last_request_ms = now;
    }
}

/* Single CAN-polling task: drives both RT data (~100 ms cycle) and the
 * optional LISP stats poll (~100 ms cycle). Each _loop() function has its
 * own internal interval gate, so calling both at 50 Hz here is fine — the
 * actual `comm_can_send_buffer()` cadence is owned by the loops, not us.
 * Keeping them on one task halves FreeRTOS overhead and serialises CAN
 * writes onto a single context (no contention on the TWAI driver). */
static void rt_task(void *arg)
{
    (void)arg;
    /* Stay off the bus for the first few seconds so the other node on it (the
     * C3 BLE helper) can complete its own exchange with the LISP script. It
     * only ever asks once per second and loses the race against our streaming
     * requests; when it loses, it reports "no data from vesc" and pedal assist
     * never commands current. This used to work only by accident — the boot
     * splash delayed our CAN bring-up — so the quiet window is explicit now.
     * See CONFIG_VESC_CAN_POLL_START_DELAY_MS. */
#if CONFIG_VESC_CAN_POLL_START_DELAY_MS > 0
    vTaskDelay(pdMS_TO_TICKS(CONFIG_VESC_CAN_POLL_START_DELAY_MS));
#endif
    for (;;) {
        vesc_rt_data_loop();
#if CONFIG_VESC_CAN_LISP_POLL_ENABLE
        /* COMM_LISP_GET_STATS — no longer feeds the dashboard (its 18-var cap
         * dropped cruise/profile); cruise + profile now come via the DASH packet
         * below. Kept behind its Kconfig for a future generic stats viewer, but
         * skipped here so it doesn't burn a serialised CAN slot for nothing. */
        (void)0;
#endif
        /* One-shot stats requests (web LISP editor's Stats tab). No-op unless
         * someone asked, so the bus stays quiet with the page closed. */
        vesc_lisp_poll_once_loop();
        vesc_io_data_loop();
        /* Dashboard cruise/profile stats over the panel's COMM_CUSTOM_APP_DATA
         * channel — replaces COMM_LISP_GET_STATS (capped at 18 vars). Always on. */
        vesc_lisp_panel_dash_loop();
        /* Quick-action panel polling lives on THIS task too (no-op unless the
         * drawer is open) so its multi-frame UI_DESC/STATE replies can't race
         * the polls above into the shared per-id CAN reassembly buffer. */
        vesc_lisp_panel_poll_loop();
        /* Ride-mode config/status, on this same serialised task and for the
         * same reason. No-op beyond a 5 Hz status poll unless the editor is
         * open or the rider pressed Save. */
        vesc_ride_mode_poll_loop();
        /* PAS setpoint forwarding + watchdog — on this same serialised CAN task.
         * Re-sends the pedal-assist current to the LISP arbiter at ~20 Hz and
         * sends 0 once if the setpoint goes stale (sensor dropped). */
        vesc_lisp_panel_pas_loop();
        vTaskDelay(pdMS_TO_TICKS(20));
    }
}

esp_err_t vesc_rt_data_start_task(void)
{
    if (s_task_handle) return ESP_OK;
    BaseType_t r = xTaskCreatePinnedToCore(rt_task, "vesc_rt", 3072, NULL, 5, &s_task_handle, 0);
    return r == pdPASS ? ESP_OK : ESP_FAIL;
}
