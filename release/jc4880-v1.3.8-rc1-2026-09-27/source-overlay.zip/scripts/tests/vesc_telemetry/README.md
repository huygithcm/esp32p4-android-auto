# VESC telemetry decoder regression cases

Run `python scripts/test_vesc_telemetry.py --cc <host-gcc>`.
The runner compiles full production `vesc_rt_data.c`, `vesc_io_data.c` and
`buffer.c` into a unique temporary directory. No firmware/simulator output
directory or hardware is used. `--baseline-ref HEAD` checks committed sources.

Fixtures use the official VESC SETUP/ADC packet layout, verified identical in
6.05, 6.06 and 7.00. Pinned reference:
[commands.c](https://github.com/vedderb/bldc/blob/20cbb362687291242ab90b99f25fbfe8835540fc/comm/commands.c#L797).
Literal bytes are independent of the production encoders, so endian/scale
mistakes cannot cancel each other between test encoding and decoding.

| Case | Required behavior |
| --- | --- |
| video_temperature_values | Decode representative -99.9, 2, 1 and -17 C values while FET stays 30 C. These are fixtures, not captured hardware packets. |
| adc_does_not_change_temperature | ADC32 varying 0/50/100% and 1/2/3 V must never change/refresh RT temperature. |
| selective_motor_only | Selective mask without FET places motor immediately after the mask. |
| full_setup_layout | Check all fields in command47, then command51 with all known mask bits and independently changed motor temperature/current/time to prove acceptance. |
| selective_mixed_fields | Decode only advertised current/voltage/uptime; leave temperature values intact. |
| unknown_trailing_field | Future mask bit/trailing bytes do not prevent decoding known temperature fields. |
| legacy_optional_tail | Preserve existing command47 acceptance of shorter replies. |
| truncated_adc | Every truncation of command32 leaves the IO snapshot untouched. |
| truncated_selective_no_refresh | A mask promising temperature bytes but no payload cannot make stale temperature fresh. |
| truncated_selective_atomic | Missing advertised current rejects the whole response, including temperature bytes. |
| truncated_current_no_field_shift | Partial 4-byte current cannot be consumed as a following 2-byte duty field. |
| all_selective_prefixes_and_recovery | Every prefix length 0..19 of a 20-byte selective reply is rejected atomically without refreshing stale data; a complete reply recovers after each rejection. |
| short_header | Missing selective header leaves snapshot unchanged. |
| other_commands | Lisp custom data/PPM/other values commands never affect SETUP snapshot. |

Scope: packet-decoder behavior only. This cannot establish the ESC sensor
configuration, electrical input, Lisp scheduling, raw CAN integrity or actual
cause of the video. A temperature already encoded in a valid ESC packet is
preserved exactly; this suite does not hide or replace negative values.

The production guard applies only to command51, where the echoed mask tells
the receiver exactly which known fields must be present. It leaves command47
legacy optional-tail behavior unchanged. The malformed-selective cases
fail on the pre-fix source; this is a reproducible parser defect, not proof
that malformed packets caused the recorded hardware temperature changes.
