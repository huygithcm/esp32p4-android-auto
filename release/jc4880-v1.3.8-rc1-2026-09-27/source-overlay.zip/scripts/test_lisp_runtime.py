"""Run the actual packaged Lisp in pinned VESC 7.00's 32-bit LispBM VM.

The VM, reader, const heap, traps and scheduler are upstream code. ESC API
fixtures are explicit host stubs; this does not validate ADC pins, CAN, motor
output, ESC timing or a different deployed firmware. No hardware is accessed.
Source downloads are immutable references; builds use a private temp directory.
Requires a 32-bit MinGW GCC (Windows). Run --source with a release main.lisp
to reproduce old failures with the same test fixture.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
REF = '20cbb362687291242ab90b99f25fbfe8835540fc'
TREE = '8364d3d29596f1a6663d017cfbab52de9ed57be6'
CACHE = ROOT / 'research/_sources/lisp-runtime-audit' / REF
FIXTURES = ROOT / 'scripts/tests/lisp_runtime'
BASE = f'https://raw.githubusercontent.com/vedderb/bldc/{REF}/lispBM/lispBM/'


def fetch(path):
    target = CACHE / path
    if not target.is_file():
        target.parent.mkdir(parents=True, exist_ok=True)
        with urllib.request.urlopen(BASE + path, timeout=30) as response:
            data = response.read()
        target.write_bytes(data)
    data = target.read_bytes()
    return {'path': path, 'url': BASE + path,
            'sha256': hashlib.sha256(data).hexdigest(), 'size': len(data)}


def sources():
    CACHE.mkdir(parents=True, exist_ok=True)
    tree_file = CACHE / 'tree.json'
    if not tree_file.is_file():
        with urllib.request.urlopen(
                f'https://api.github.com/repos/vedderb/bldc/git/trees/{TREE}?recursive=1',
                timeout=30) as response:
            tree_file.write_bytes(response.read())
    tree = json.loads(tree_file.read_bytes())['tree']
    paths = [entry['path'] for entry in tree if entry['type'] == 'blob' and (
        entry['path'].startswith(('include/', 'src/', 'platform/windows/'))
        or entry['path'] in ('lispbm.mk', 'LICENSE', 'tests/test_lisp_code_cps.c'))]
    with ThreadPoolExecutor(max_workers=8) as pool:
        manifest = list(pool.map(fetch, paths))
    # Verify cached bytes against Git's immutable blob identifiers as well.
    blob_ids = {entry['path']: entry['sha'] for entry in tree}
    for entry in manifest:
        data = (CACHE / entry['path']).read_bytes()
        blob = b'blob ' + str(len(data)).encode() + b'\0' + data
        if hashlib.sha1(blob).hexdigest() != blob_ids[entry['path']]:
            raise RuntimeError(f'Upstream blob mismatch: {entry["path"]}')
    (CACHE / 'provenance.json').write_text(json.dumps(
        {'bldc_ref': REF, 'lispbm_tree': TREE, 'files': manifest}, indent=2) + '\n')
    makefile = (CACHE / 'lispbm.mk').read_text()
    block = makefile.split('LISPBM_SRC =', 1)[1].split('LISPBM_H =', 1)[0]
    return [CACHE / path for path in re.findall(r'\$\(LISPBM\)/(\S+\.c)', block)]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, default=ROOT / 'lisp/main.lisp')
    parser.add_argument('--cc', default=shutil.which('gcc') or 'C:/msys64/mingw32/bin/gcc.exe')
    args = parser.parse_args()
    src = sources()
    env = dict(os.environ)
    env['PATH'] = str(Path(args.cc).resolve().parent) + os.pathsep + env.get('PATH', '')
    with tempfile.TemporaryDirectory(prefix='vesc-lisp-runtime-') as tmp:
        tmp = Path(tmp)
        exe = tmp / 'lisp_runtime.exe'
        command = [args.cc, '-std=gnu11', '-O1', '-DFULL_RTS_LIB',
                   # MinGW exposes C99 isnan/isinf, not the GNU float aliases.
                   '-Disnanf=__builtin_isnan', '-Disinff=__builtin_isinf',
                   '-DLBM_USE_DYN_FUNS', '-DLBM_USE_DYN_MACROS', '-DLBM_USE_DYN_LOOPS',
                   '-DLBM_USE_DYN_ARRAYS', '-DLBM_USE_ERROR_LINENO',
                   '-I' + str(CACHE / 'include'), '-I' + str(CACHE / 'include/extensions'),
                   '-I' + str(CACHE / 'src'), '-I' + str(CACHE / 'platform/windows/include'),
                   *map(str, src), str(CACHE / 'platform/windows/src/platform_mutex.c'),
                   str(CACHE / 'platform/windows/src/platform_timestamp.c'),
                   str(FIXTURES / 'runner.c'), '-o', str(exe), '-lm']
        subprocess.run(command, check=True, env=env, cwd=tmp)
        program = tmp / 'test.lisp'
        program.write_text((FIXTURES / 'esc_api_fixture.lisp').read_text() + '\n' +
                           args.source.read_text(encoding='utf-8-sig') + '\n' +
                           (FIXTURES / 'cases.lisp').read_text(), encoding='utf-8')
        print(f'Upstream LispBM: bldc {REF}; 32-bit host; source {args.source}', flush=True)
        result = subprocess.run([str(exe), str(program)], env=env, cwd=tmp,
                                timeout=30, check=False)
        return result.returncode


if __name__ == '__main__':
    raise SystemExit(main())
